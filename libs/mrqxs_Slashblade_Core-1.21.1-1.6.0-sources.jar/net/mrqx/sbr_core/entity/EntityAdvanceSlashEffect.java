package net.mrqx.sbr_core.entity;

import com.mojang.math.Axis;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.entity.EntitySlashEffect;
import mods.flammpfeil.slashblade.entity.Projectile;
import mods.flammpfeil.slashblade.event.handler.FallHandler;
import mods.flammpfeil.slashblade.util.NBTHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.utils.SlashBladeAttackUtils;
import org.joml.Vector4f;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class EntityAdvanceSlashEffect extends EntitySlashEffect {
    private static final EntityDataAccessor<String> MODEL_LOCATION = SynchedEntityData.defineId(EntityAdvanceSlashEffect.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> TEXTURE_LOCATION = SynchedEntityData.defineId(EntityAdvanceSlashEffect.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> RENDER_CONSUMER_ID = SynchedEntityData.defineId(EntityAdvanceSlashEffect.class, EntityDataSerializers.STRING);
    
    private static final ResourceLocation DEFAULT_MODEL_LOCATION = SlashBlade.prefix("model/util/slash.obj");
    private static final ResourceLocation DEFAULT_TEXTURE_LOCATION = SlashBlade.prefix("model/util/slash.png");
    private static final ResourceLocation DEFAULT_RENDER_CONSUMER_ID = MrqxSlashBladeCore.prefix("default");
    
    @Nullable
    private DamageSource damageSource;
    
    public EntityAdvanceSlashEffect(EntityType<? extends Projectile> entityTypeIn, Level worldIn) {
        super(entityTypeIn, worldIn);
    }
    
    @Override
    public void tick() {
        //<editor-fold desc="Avoid super attack">
        Entity owner = this.getOwner();
        List<Entity> alreadyHits = new ArrayList<>(this.getAlreadyHits());
        this.setOwner(null);
        super.tick();
        this.setOwner(owner);
        this.getAlreadyHits().clear();
        this.getAlreadyHits().addAll(alreadyHits);
        //</editor-fold>
        
        float baseSize = this.getBaseSize();
        
        if (this.tickCount % 2 == 0 || this.tickCount < 5) {
            Vec3 start = this.position();
            Vector4f normal = new Vector4f(1, 0, 0, 1);
            Vector4f dir = new Vector4f(0, 0, 1, 1);
            
            float progress = (float) this.tickCount / this.getLifetime();
            
            Axis.YP.rotationDegrees(60 + this.getRotationOffset() - 200.0F * progress).transform(normal);
            Axis.ZP.rotationDegrees(this.getRotationRoll()).transform(normal);
            Axis.XP.rotationDegrees(this.getXRot()).transform(normal);
            Axis.YP.rotationDegrees(-this.getYRot()).transform(normal);
            
            Axis.YP.rotationDegrees(60 + this.getRotationOffset() - 200 * progress).transform(dir);
            Axis.ZP.rotationDegrees(this.getRotationRoll()).transform(dir);
            Axis.XP.rotationDegrees(this.getXRot()).transform(dir);
            Axis.YP.rotationDegrees(-this.getYRot()).transform(dir);
            
            Vec3 normal3d = new Vec3(normal.x(), normal.y(), normal.z());
            
            BlockHitResult rayResult = this.level().clip(new ClipContext(start.add(normal3d.scale(1.5F)),
                start.add(normal3d.scale(3.0F)), ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, this));
            
            if (this.getShooter() != null && !this.getShooter().isInWaterOrRain() && rayResult.getType() == HitResult.Type.BLOCK) {
                FallHandler.spawnLandingParticle(this, rayResult.getLocation(), normal3d, 3.0F);
            }
        }
        
        DamageSource damageSource = this.getDamageSource();
        if (this.getShooter() != null && damageSource != null) {
            if (this.tickCount % 2 == 0) {
                boolean forceHit = true;
                
                List<Entity> hits;
                if (!this.getIndirect() && this.getShooter() instanceof LivingEntity shooter) {
                    float ratio = (float) this.getDamage() * (this.getIsCritical() ? 1.1f : 1.0f);
                    AttributeInstance instance = baseSize != 1 ? shooter.getAttribute(Attributes.ENTITY_INTERACTION_RANGE) : null;
                    if (instance != null) {
                        AttributeModifier modifier = new AttributeModifier(SLASH_BASE_SIZE_ATTRIBUTE_ID, baseSize, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
                        instance.addTransientModifier(modifier);
                    }
                    hits = SlashBladeAttackUtils.areaAttackWithDamageSource(shooter, this.getKnockBack().action, ratio, forceHit, false, true, this.getAlreadyHits(), damageSource);
                    if (instance != null) {
                        instance.removeModifier(SLASH_BASE_SIZE_ATTRIBUTE_ID);
                    }
                } else {
                    hits = SlashBladeAttackUtils.areaAttackWithDamageSource(this, this.getKnockBack().action, 4 * baseSize, forceHit, false, this.getAlreadyHits(), damageSource);
                }
                
                if (!this.doCycleHit()) {
                    this.getAlreadyHits().addAll(hits);
                }
            }
        }
    }
    
    
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(MODEL_LOCATION, DEFAULT_MODEL_LOCATION.toString());
        builder.define(TEXTURE_LOCATION, DEFAULT_TEXTURE_LOCATION.toString());
        builder.define(RENDER_CONSUMER_ID, DEFAULT_RENDER_CONSUMER_ID.toString());
    }
    
    @Override
    protected void addAdditionalSaveData(CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        
        NBTHelper.getNBTCoupler(compound)
            .put("modelLocation", this.getModelLocation())
            .put("textureLocation", this.getTextureLocation())
            .put("renderConsumerId", this.getRenderConsumerId());
    }
    
    @Override
    protected void readAdditionalSaveData(CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        
        NBTHelper.getNBTCoupler(compound)
            .get("modelLocation", this::setModelLocation)
            .get("textureLocation", this::setTextureLocation)
            .get("renderConsumerId", this::setRenderConsumerId);
    }
    
    public ResourceLocation getModelLocation() {
        ResourceLocation resourceLocation = ResourceLocation.tryParse(this.getEntityData().get(MODEL_LOCATION));
        return resourceLocation != null ? resourceLocation : DEFAULT_MODEL_LOCATION;
    }
    
    public void setModelLocation(ResourceLocation value) {
        this.getEntityData().set(MODEL_LOCATION, value.toString());
    }
    
    public ResourceLocation getTextureLocation() {
        ResourceLocation resourceLocation = ResourceLocation.tryParse(this.getEntityData().get(TEXTURE_LOCATION));
        return resourceLocation != null ? resourceLocation : DEFAULT_TEXTURE_LOCATION;
    }
    
    public void setTextureLocation(ResourceLocation value) {
        this.getEntityData().set(TEXTURE_LOCATION, value.toString());
    }
    
    public ResourceLocation getRenderConsumerId() {
        ResourceLocation resourceLocation = ResourceLocation.tryParse(this.getEntityData().get(RENDER_CONSUMER_ID));
        return resourceLocation != null ? resourceLocation : DEFAULT_RENDER_CONSUMER_ID;
    }
    
    public void setRenderConsumerId(ResourceLocation value) {
        this.getEntityData().set(RENDER_CONSUMER_ID, value.toString());
    }
    
    public void setDamageSource(@Nullable DamageSource damageSource) {
        this.damageSource = damageSource;
    }
    
    @Nullable
    public DamageSource getDamageSource() {
        return damageSource;
    }
    
}
