package net.mrqx.sbr_core.events;

import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.client.renderer.entity.RendererAdvanceSlashEffect;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.event.IModBusEvent;

import java.util.HashMap;
import java.util.Map;

public class AdvanceSlashEffectRenderConsumerRegistryEvent extends Event implements IModBusEvent {
    private final Map<ResourceLocation, RendererAdvanceSlashEffect.AdvanceSlashEffectRenderConsumer> consumers;
    
    public AdvanceSlashEffectRenderConsumerRegistryEvent() {
        this.consumers = new HashMap<>();
    }
    
    public void registerConsumer(ResourceLocation id, RendererAdvanceSlashEffect.AdvanceSlashEffectRenderConsumer consumer) {
        this.consumers.put(id, consumer);
    }
    
    public Map<ResourceLocation, RendererAdvanceSlashEffect.AdvanceSlashEffectRenderConsumer> getConsumers() {
        return this.consumers;
    }
}
