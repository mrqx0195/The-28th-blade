package net.mrqx.sbr_core.events.handler;

import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.registry.SlashBladeItems;
import net.minecraft.world.entity.LivingEntity;
import net.mrqx.sbr_core.registry.MrqxComboStateRegistry;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.loading.FMLEnvironment;

@EventBusSubscriber
public final class DebugHandler {
    @SubscribeEvent
    public static void onInput(SlashBladeEvent.PerformSlashArtEvent event) {
        // TODO: WIP......
        LivingEntity player = event.getEntityLiving();
        if (!FMLEnvironment.production && player.getOffhandItem().is(SlashBladeItems.PROUDSOUL_TRAPEZOHEDRON)) {
            event.getSlashBladeState().setComboRoot(MrqxComboStateRegistry.VANILLA_STYLE_STANDBY.getId());
        }
//        LivingEntity player = event.getEntityLiving();
//        if (!FMLEnvironment.production && player.getOffhandItem().is(SlashBladeItems.PROUDSOUL_TRAPEZOHEDRON)) {
//            Vec3 position = player.position();
//            if (player.isShiftKeyDown()) {
//                PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
//                    new JudgementCutEndRangeEffectMessage(position));
//                return;
//            }
//            int variant = player.getOffhandItem().getCount();
//            CustomPacketPayload message;
//            if (variant >= 4) {
//                message = new DimensionSlashBossEffectMessage(position.add(0, 5, 0));
//            } else if (variant == 3) {
//                message = new DimensionSlashPerfectEffectMessage(position.add(0, 5, 0));
//            } else if (variant == 2) {
//                message = new DimensionSlashNormalEffectMessage(position.add(0, 5, 0));
//            } else {
//                message = new JudgementCutEndEffectMessage(position);
//            }
//            PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, message);
//        }
    }
}
