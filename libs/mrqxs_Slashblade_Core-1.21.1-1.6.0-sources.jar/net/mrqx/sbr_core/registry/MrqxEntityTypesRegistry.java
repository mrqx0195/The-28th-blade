package net.mrqx.sbr_core.registry;

import com.google.common.base.CaseFormat;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.mrqx.sbr_core.entity.EntityAdvanceSlashEffect;
import net.mrqx.sbr_core.entity.EntityAirTrickSummonedSword;
import net.mrqx.sbr_core.entity.EntitySlashString;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class MrqxEntityTypesRegistry {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, MrqxSlashBladeCore.MODID);
    
    public static final DeferredHolder<EntityType<?>, EntityType<EntityAdvanceSlashEffect>> ADVANCE_SLASH_EFFECT = ENTITY_TYPES.register(classToString(EntityAdvanceSlashEffect.class), () ->
        EntityType.Builder.of(EntityAdvanceSlashEffect::new, MobCategory.MISC)
            .sized(3.0F, 3.0F).setTrackingRange(4).setUpdateInterval(20)
            .build(MrqxSlashBladeCore.prefix(classToString(EntityAdvanceSlashEffect.class)).toString()));
    public static final DeferredHolder<EntityType<?>, EntityType<EntityAirTrickSummonedSword>> AIR_TRICK_SUMMONED_SWORD = ENTITY_TYPES.register(classToString(EntityAirTrickSummonedSword.class), () ->
        EntityType.Builder.of(EntityAirTrickSummonedSword::new, MobCategory.MISC)
            .sized(3.0F, 3.0F).setTrackingRange(4).setUpdateInterval(20)
            .build(MrqxSlashBladeCore.prefix(classToString(EntityAirTrickSummonedSword.class)).toString()));
    public static final DeferredHolder<EntityType<?>, EntityType<EntitySlashString>> SLASH_STRING = ENTITY_TYPES.register(classToString(EntitySlashString.class), () ->
        EntityType.Builder.of(EntitySlashString::new, MobCategory.MISC)
            .sized(3.0F, 3.0F).setTrackingRange(4).setUpdateInterval(20)
            .build(MrqxSlashBladeCore.prefix(classToString(EntitySlashString.class)).toString()));
    
    /**
     * 将实体类名转换为小写下划线格式的资源路径后缀。
     */
    public static String classToString(Class<? extends Entity> entityClass) {
        return CaseFormat.UPPER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, entityClass.getSimpleName()).replace("entity_", "");
    }
}
