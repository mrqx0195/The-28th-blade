package mods.flammpfeil.slashblade.entity;

import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.ability.StunManager;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.util.AttackManager;
import mods.flammpfeil.slashblade.util.EnumSetConverter;
import mods.flammpfeil.slashblade.util.NBTHelper;
import mods.flammpfeil.slashblade.util.TargetSelector;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.*;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.entity.PartEntity;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import static mods.flammpfeil.slashblade.SlashBladeConfig.SLASHBLADE_DAMAGE_MULTIPLIER;

public class EntityAbstractSummonedSword extends Projectile implements IShootable {
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData
        .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> FLAGS = SynchedEntityData
        .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> HIT_ENTITY_ID = SynchedEntityData
        .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> OFFSET_YAW = SynchedEntityData
        .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROLL = SynchedEntityData
        .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Byte> PIERCE = SynchedEntityData.defineId(EntityAbstractSummonedSword.class,
        EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<String> MODEL = SynchedEntityData
        .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> DELAY = SynchedEntityData
        .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.INT);

    private int ticksInGround;
    private boolean inGround;
    @Nullable
    private BlockState inBlockState;
    private int ticksInAir;
    private double damage = 1.0D;
    @Nullable
    private IntOpenHashSet alreadyHits;
    @Nullable
    private Entity hitEntity = null;

    static final int ON_GROUND_LIFE_TIME = 20 * 5;

    private final SoundEvent hitEntitySound = SoundEvents.TRIDENT_HIT;
    private final SoundEvent hitEntityPlayerSound = SoundEvents.TRIDENT_HIT;
    private final SoundEvent hitGroundSound = SoundEvents.TRIDENT_HIT_GROUND;

    protected SoundEvent getHitEntitySound() {
        return this.hitEntitySound;
    }

    protected SoundEvent getHitEntityPlayerSound() {
        return this.hitEntityPlayerSound;
    }

    protected SoundEvent getHitGroundSound() {
        return this.hitGroundSound;
    }

    public EntityAbstractSummonedSword(EntityType<? extends Projectile> entityTypeIn, Level worldIn) {
        super(entityTypeIn, worldIn);
        this.setNoGravity(true);
        // this.setGlowing(true);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(COLOR, 0x3333FF);
        builder.define(FLAGS, 0);
        builder.define(HIT_ENTITY_ID, -1);
        builder.define(OFFSET_YAW, 0f);
        builder.define(ROLL, 0f);
        builder.define(PIERCE, (byte) 0);
        builder.define(MODEL, "");
        builder.define(DELAY, 10);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag compound) {
        super.addAdditionalSaveData(compound);

        NBTHelper.getNBTCoupler(compound).put("Color", this.getColor()).put("life", (short) this.ticksInGround)
            .put("inBlockState", (this.inBlockState != null ? NbtUtils.writeBlockState(this.inBlockState) : null))
            .put("inGround", this.inGround).put("damage", this.damage).put("crit", this.getIsCritical())
            .put("clip", this.isNoClip()).put("PierceLevel", this.getPierce()).put("model", this.getModelName())
            .put("Delay", this.getDelay());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag compound) {
        super.readAdditionalSaveData(compound);

        NBTHelper.getNBTCoupler(compound).get("Color", this::setColor)
            .get("life", ((Integer v) -> this.ticksInGround = v))
            .get("inBlockState",
                ((CompoundTag v) -> this.inBlockState = NbtUtils
                    .readBlockState(this.level().holderLookup(Registries.BLOCK), v)))
            .get("inGround", ((Boolean v) -> this.inGround = v))
            .get("damage", ((Double v) -> this.damage = v), this.damage).get("crit", this::setIsCritical)
            .get("clip", this::setNoClip).get("PierceLevel", this::setPierce).get("model", this::setModelName)
            .get("Delay", this::setDelay);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket(ServerEntity entity) {
        return super.getAddEntityPacket(entity);
    }

    @Override
    public void shoot(double x, double y, double z, float velocity, float inaccuracy) {
        Vec3 vec3d = (new Vec3(x, y, z)).normalize()
            .add(this.random.nextGaussian() * (double) 0.0075F * (double) inaccuracy,
                this.random.nextGaussian() * (double) 0.0075F * (double) inaccuracy,
                this.random.nextGaussian() * (double) 0.0075F * (double) inaccuracy)
            .scale(velocity);
        this.setDeltaMovement(vec3d);
        float f = Mth.sqrt((float) vec3d.horizontalDistanceSqr());
        this.setPos(this.position());
        this.setYRot((float) (Mth.atan2(vec3d.x, vec3d.z) * (double) (180F / (float) Math.PI)));
        this.setXRot((float) (Mth.atan2(vec3d.y, f) * (double) (180F / (float) Math.PI)));
        this.yRotO = this.getYRot();
        this.xRotO = this.getXRot();
        this.ticksInGround = 0;
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public boolean shouldRenderAtSqrDistance(double distance) {
        double d0 = this.getBoundingBox().getSize() * 10.0D;
        if (Double.isNaN(d0)) {
            d0 = 1.0D;
        }

        d0 = d0 * 64.0D * getViewScale();
        return distance < d0 * d0;
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public void lerpTo(double x, double y, double z, float yaw, float pitch, int steps) {
        this.setPos(x, y, z);
        this.setRot(yaw, pitch);
    }

    @Override
    @OnlyIn(Dist.CLIENT)
    public void lerpMotion(double x, double y, double z) {
        this.setDeltaMovement(x, y, z);
        if (this.xRotO == 0.0F && this.yRotO == 0.0F) {
            float f = Mth.sqrt((float) (x * x + z * z));
            this.setXRot((float) (Mth.atan2(y, f) * (double) (180F / (float) Math.PI)));
            this.setYRot((float) (Mth.atan2(x, z) * (double) (180F / (float) Math.PI)));
            this.xRotO = this.getXRot();
            this.yRotO = this.getYRot();
            this.moveTo(this.getX(), this.getY(), this.getZ(), this.getYRot(), this.getXRot());
            this.ticksInGround = 0;
        }

    }

    public enum FlagsState {
        Critical, NoClip,
    }

    protected EnumSet<FlagsState> flags = EnumSet.noneOf(FlagsState.class);
    protected int intFlags = 0;

    protected void setFlags(FlagsState value) {
        this.flags.add(value);
        refreshFlags();
    }

    protected void removeFlags(FlagsState value) {
        this.flags.remove(value);
        refreshFlags();
    }

    private void refreshFlags() {
        if (this.level().isClientSide()) {
            int newValue = this.entityData.get(FLAGS);
            if (intFlags != newValue) {
                intFlags = newValue;
                flags = EnumSetConverter.convertToEnumSet(FlagsState.class, intFlags);
            }
        } else {
            int newValue = EnumSetConverter.convertToInt(this.flags);
            if (this.intFlags != newValue) {
                this.entityData.set(FLAGS, newValue);
                this.intFlags = newValue;
            }
        }
    }

    public void setIsCritical(boolean value) {
        if (value) {
            setFlags(FlagsState.Critical);
        } else {
            removeFlags(FlagsState.Critical);
        }
    }

    public boolean getIsCritical() {
        refreshFlags();
        return flags.contains(FlagsState.Critical);
    }

    public void setNoClip(boolean value) {
        this.noPhysics = value;
        if (value) {
            setFlags(FlagsState.NoClip);
        } else {
            removeFlags(FlagsState.NoClip);
        }
    }

    // disallowedHitBlock
    public boolean isNoClip() {
        if (!this.level().isClientSide()) {
            return this.noPhysics;
        } else {
            refreshFlags();
            return flags.contains(FlagsState.NoClip);
        }
    }

    @Override
    public void tick() {
        super.tick();

        if (getHitEntity() != null) {
            Entity hits = getHitEntity();

            if (!hits.isAlive()) {
                this.burst();
            } else {
                this.setPos(hits.getX(), hits.getY() + hits.getEyeHeight() * 0.5f, hits.getZ());

                int delay = getDelay();
                delay--;
                setDelay(delay);

                if (!this.level().isClientSide() && delay < 0) {
                    this.burst();
                }
            }

            return;
        }

        boolean disallowedHitBlock = this.isNoClip();

        BlockPos blockpos = this.getOnPos();
        BlockState blockstate = this.level().getBlockState(blockpos);
        if (!blockstate.isAir() && !disallowedHitBlock) {
            VoxelShape voxelshape = blockstate.getCollisionShape(this.level(), blockpos);
            if (!voxelshape.isEmpty()) {
                for (AABB axisalignedbb : voxelshape.toAabbs()) {
                    if (axisalignedbb.move(blockpos).contains(new Vec3(this.getX(), this.getY(), this.getZ()))) {
                        this.inGround = true;
                        break;
                    }
                }
            }
        }

        if (this.isInWaterOrRain()) {
            this.clearFire();
        }

        if (this.inGround && !disallowedHitBlock) {
            // onBlock
            if (this.inBlockState != null && !this.inBlockState.equals(blockstate)
                && this.level().noCollision(this.getBoundingBox().inflate(0.06D))) {
                // block breaked
                this.burst();
            }
        } else {
            // process pose
            Vec3 motionVec = this.getDeltaMovement();
            if (this.xRotO == 0.0F && this.yRotO == 0.0F) {
                float f = Mth.sqrt((float) motionVec.horizontalDistanceSqr());
                this.setYRot((float) (Mth.atan2(motionVec.x, motionVec.z) * (double) (180F / (float) Math.PI)));
                this.setXRot((float) (Mth.atan2(motionVec.y, f) * (double) (180F / (float) Math.PI)));
                this.yRotO = this.getYRot();
                this.xRotO = this.getXRot();
            }

            // process inAir
            ++this.ticksInAir;
            Vec3 positionVec = this.position();
            Vec3 movedVec = positionVec.add(motionVec);
            HitResult raytraceresult = this.level().clip(
                new ClipContext(positionVec, movedVec, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (raytraceresult.getType() != HitResult.Type.MISS) {
                movedVec = raytraceresult.getLocation();
            }

            while (this.isAlive()) {
                // todo : replace TargetSelector
                EntityHitResult entityHit = this.getRayTrace(positionVec, movedVec);
                if (entityHit != null) {
                    raytraceresult = entityHit;
                }

                if (raytraceresult == null) {
                    break;
                }

                boolean impactCheck = !net.neoforged.neoforge.event.EventHooks.onProjectileImpact(this, raytraceresult);

                if (raytraceresult.getType() == HitResult.Type.ENTITY && impactCheck) {
                    Entity target = null;
                    if (raytraceresult instanceof EntityHitResult entityHitResult) {
                        target = entityHitResult.getEntity();
                    }
                    Entity shooter = this.getShooter();
                    if (target instanceof LivingEntity && shooter instanceof LivingEntity) {
                        if (!TargetSelector.test.test((LivingEntity) shooter, (LivingEntity) target)) {
                            raytraceresult = null;
                            entityHit = null;
                        }
                    }
                }

                if (raytraceresult != null
                    && !(disallowedHitBlock && raytraceresult.getType() == HitResult.Type.BLOCK)
                    && impactCheck) {
                    this.onHit(raytraceresult);
                    this.hasImpulse = true;
                } else if (!impactCheck && entityHit != null) {
                    Entity cancelledTarget = entityHit.getEntity();
                    if (this.alreadyHits == null) {
                        this.alreadyHits = new IntOpenHashSet(5);
                    }
                    this.alreadyHits.add(cancelledTarget.getId());
                }

                if (entityHit == null || this.getPierce() <= 0) {
                    break;
                }

                raytraceresult = null;
            }

            motionVec = this.getDeltaMovement();
            double mx = motionVec.x;
            double my = motionVec.y;
            double mz = motionVec.z;
            if (this.getIsCritical()) {
                for (int i = 0; i < 4; ++i) {
                    this.level().addParticle(ParticleTypes.CRIT, this.getX() + mx * (double) i / 4.0D,
                        this.getY() + my * (double) i / 4.0D, this.getZ() + mz * (double) i / 4.0D, -mx, -my + 0.2D,
                        -mz);
                }
            }

            this.setPos(this.getX() + mx, this.getY() + my, this.getZ() + mz);
            float f4 = Mth.sqrt((float) motionVec.horizontalDistanceSqr());
            if (disallowedHitBlock) {
                this.setYRot((float) (Mth.atan2(-mx, -mz) * (double) (180F / (float) Math.PI)));
            } else {
                this.setYRot((float) (Mth.atan2(mx, mz) * (double) (180F / (float) Math.PI)));
            }

            this.setXRot((float) (Mth.atan2(my, f4) * (double) (180F / (float) Math.PI)));
            while (this.getXRot()
                - this.xRotO < -180.0F) {
                this.xRotO -= 360.0F;
            }

            while (this.getXRot() - this.xRotO >= 180.0F) {
                this.xRotO += 360.0F;
            }

            while (this.getYRot() - this.yRotO < -180.0F) {
                this.yRotO -= 360.0F;
            }

            while (this.getYRot() - this.yRotO >= 180.0F) {
                this.yRotO += 360.0F;
            }

            this.setXRot(Mth.lerp(0.2F, this.xRotO, this.getXRot()));
            this.setYRot(Mth.lerp(0.2F, this.yRotO, this.getYRot()));
            float f1 = 0.99F;
            if (this.isInWater()) {
                for (int j = 0; j < 4; ++j) {
                    this.level().addParticle(ParticleTypes.BUBBLE, this.getX() - mx * 0.25D, this.getY() - my * 0.25D,
                        this.getZ() - mz * 0.25D, mx, my, mz);
                }
            }

            this.setDeltaMovement(motionVec.scale(f1));
            if (!this.isNoGravity() && !disallowedHitBlock) {
                Vec3 vec3d3 = this.getDeltaMovement();
                this.setDeltaMovement(vec3d3.x, vec3d3.y - (double) 0.05F, vec3d3.z);
            }

            // this.setPosition(this.getPosX(), this.getPosY(), this.getPosZ());
            this.checkInsideBlocks();
        }

        if (!this.level().isClientSide() && ticksInGround <= 0 && 100 < this.tickCount) {
            this.remove(RemovalReason.DISCARDED);
        }

    }

    protected void tryDespawn() {
        ++this.ticksInGround;
        if (ON_GROUND_LIFE_TIME <= this.ticksInGround) {
            this.burst();
        }

    }

    @Override
    protected void onHit(HitResult raytraceResultIn) {
        if (raytraceResultIn == null){
            return;
        }
        HitResult.Type type = raytraceResultIn.getType();
        switch (type) {
            case ENTITY:
                this.onHitEntity((EntityHitResult) raytraceResultIn);
                break;
            case BLOCK:
                this.onHitBlock((BlockHitResult) raytraceResultIn);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult blockraytraceresult) {
        BlockState blockstate = this.level().getBlockState(blockraytraceresult.getBlockPos());
        this.inBlockState = blockstate;
        Vec3 vec3d = blockraytraceresult.getLocation().subtract(this.getX(), this.getY(), this.getZ());
        this.setDeltaMovement(vec3d);
        Vec3 vec3d1 = this.position().subtract(vec3d.normalize().scale(0.05F));
        this.setPos(vec3d1.x, vec3d1.y, vec3d1.z);
        this.playSound(this.getHitGroundSound(), 1.0F, 2.2F / (this.random.nextFloat() * 0.2F + 0.9F));
        this.inGround = true;
        this.setIsCritical(false);
        this.setPierce((byte) 0);
        this.resetAlreadyHits();
        blockstate.onProjectileHit(this.level(), blockstate, blockraytraceresult, this);
    }

    public void doForceHitEntity(Entity target) {
        onHitEntity(new EntityHitResult(target));
    }

    @Override
    protected void onHitEntity(EntityHitResult entityHitResult) {
        Entity targetEntity = entityHitResult.getEntity();

        SlashBladeEvent.SummonedSwordOnHitEntityEvent event = new SlashBladeEvent.SummonedSwordOnHitEntityEvent(this, targetEntity);
        NeoForge.EVENT_BUS.post(event);

        int i = Mth.ceil(this.getDamage());
        if (this.getPierce() > 0) {
            if (this.alreadyHits == null) {
                this.alreadyHits = new IntOpenHashSet(5);
            }

            if (this.alreadyHits.size() >= this.getPierce() + 1) {
                this.burst();
                return;
            }

            this.alreadyHits.add(targetEntity.getId());
        }

        if (this.getIsCritical()) {
            i += this.random.nextInt(i / 2 + 2);
        }

        Entity shooter = this.getShooter();
        DamageSource damagesource;
        if (shooter == null) {
            damagesource = this.damageSources().indirectMagic(this, this);
        } else {
            damagesource = this.damageSources().indirectMagic(this, shooter);
            if (shooter instanceof LivingEntity) {
                Entity hits = targetEntity;
                if (targetEntity instanceof PartEntity) {
                    hits = ((PartEntity<?>) targetEntity).getParent();
                }
                ((LivingEntity) shooter).setLastHurtMob(hits);
            }
        }

        int fireTime = targetEntity.getRemainingFireTicks();
        if (this.isOnFire() && !(targetEntity instanceof EnderMan)) {
            targetEntity.setRemainingFireTicks(5 * 20);
        }

        // todo: attack manager
        targetEntity.invulnerableTime = 0;
        float scale = 1f;
        if (shooter instanceof LivingEntity living) {
            scale = (float) (AttackManager.getSlashBladeDamageScale(living) * SLASHBLADE_DAMAGE_MULTIPLIER.get());
        }
        float damageValue = i * scale;
        if (targetEntity.hurt(damagesource, damageValue)) {
            Entity hits = targetEntity;
            if (targetEntity instanceof PartEntity) {
                hits = ((PartEntity<?>) targetEntity).getParent();
            }

            if (hits instanceof LivingEntity targetLivingEntity) {

                StunManager.setStun(targetLivingEntity);

                if (!this.level().isClientSide() && this.getPierce() <= 0) {
                    setHitEntity(hits);
                }

                if (!this.level().isClientSide() && shooter instanceof LivingEntity) {
                    EnchantmentHelper.doPostAttackEffects((ServerLevel) this.level(), targetLivingEntity, damagesource);
                }

                // this.arrowHit(targetLivingEntity);

                affectEntity(targetLivingEntity, getPotionEffects(), 1.0f);

                if (!targetLivingEntity.equals(shooter) && targetLivingEntity instanceof Player
                    && shooter instanceof ServerPlayer) {
                    ((ServerPlayer) shooter).playNotifySound(this.getHitEntityPlayerSound(), SoundSource.PLAYERS, 0.18F,
                        0.45F);
                }
            }

            this.playSound(this.getHitEntitySound(), 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
            if (this.getPierce() <= 0 && (getHitEntity() == null || !getHitEntity().isAlive())) {
                this.burst();
            }
        } else {
            targetEntity.setRemainingFireTicks(fireTime);
            // this.setMotion(this.getMotion().scale(-0.1D));
            // this.setYRot(this.getYRot() + 180.0F);
            // this.yRotO += 180.0F;
            this.ticksInAir = 0;
            if (!this.level().isClientSide() && this.getDeltaMovement().lengthSqr() < 1.0E-7D) {
                if (getPierce() <= 1) {
                    this.burst();
                } else {
                    this.setPierce((byte) (getPierce() - 1));
                }
            }
        }

    }

    public int getColor() {
        return this.getEntityData().get(COLOR);
    }

    public void setColor(int value) {
        this.getEntityData().set(COLOR, value);
    }

    public byte getPierce() {
        return this.getEntityData().get(PIERCE);
    }

    public void setPierce(byte value) {
        this.getEntityData().set(PIERCE, value);
    }

    public int getDelay() {
        return this.getEntityData().get(DELAY);
    }

    public void setDelay(int value) {
        this.getEntityData().set(DELAY, value);
    }

    @Nullable
    protected EntityHitResult getRayTrace(Vec3 p_213866_1_, Vec3 p_213866_2_) {
        return ProjectileUtil.getEntityHitResult(this.level(), this, p_213866_1_, p_213866_2_,
            this.getBoundingBox().expandTowards(this.getDeltaMovement()).inflate(1.0D), (entity) -> entity.canBeHitByProjectile() && !entity.isSpectator()
                && (!entity.equals(this.getShooter()) || this.ticksInAir >= 5)
                && (this.alreadyHits == null || !this.alreadyHits.contains(entity.getId())));
    }

    @Nullable
    @Override
    public Entity getShooter() {
        return this.getOwner();
    }

    @Override
    public void setShooter(Entity shooter) {
        setOwner(shooter);
    }

    public List<MobEffectInstance> getPotionEffects() {
        List<MobEffectInstance> effects = new ArrayList<>();
        CompoundTag data = this.getPersistentData();
        if (data.contains("CustomPotionEffects", 9)) {
            var list = data.getList("CustomPotionEffects", 10);
            for (int i = 0; i < list.size(); i++) {
                effects.add(MobEffectInstance.load(list.getCompound(i)));
            }
        }

        if (effects.isEmpty()) {
            effects.add(new MobEffectInstance(MobEffects.POISON, 1, 1));
        }

        return effects;
    }

    public void burst() {
        this.playSound(SoundEvents.GLASS_BREAK, 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));

        if (!this.level().isClientSide()) {
            if (this.level() instanceof ServerLevel) {
                ((ServerLevel) this.level()).sendParticles(ParticleTypes.CRIT, this.getX(), this.getY(), this.getZ(),
                    16, 0.5, 0.5, 0.5, 0.25f);
            }

            this.burst(getPotionEffects(), null);
        }

        super.remove(RemovalReason.DISCARDED);
    }

    public void burst(List<MobEffectInstance> effects, @Nullable Entity focusEntity) {
        // AABB axisalignedbb = this.getBoundingBox().inflate(4.0D, 2.0D, 4.0D);
        List<Entity> list = TargetSelector.getTargettableEntitiesWithinAABB(this.level(), 2, this);
        // this.world.getEntitiesWithinAABB(LivingEntity.class, axisalignedbb);

        list.stream().filter(e -> e instanceof LivingEntity).map(e -> (LivingEntity) e).forEach(e -> {
            double distanceSq = TargetSelector.distanceSqrBetweenEntity(this, e);
            if (distanceSq < 9.0D) {
                double factor = 1.0D - Math.sqrt(distanceSq) / 4.0D;
                if (e.equals(focusEntity)) {
                    factor = 1.0D;
                }

                affectEntity(e, effects, factor);
            }
        });
    }

    public void affectEntity(LivingEntity focusEntity, List<MobEffectInstance> effects, double factor) {
        for (MobEffectInstance effectinstance : getPotionEffects()) {
            var effect = effectinstance.getEffect();
            if (effect.value().isInstantenous()) {
                effect.value().applyInstantenousEffect(this, this.getShooter(), focusEntity, effectinstance.getAmplifier(),
                    factor);
            } else {
                int duration = (int) (factor * (double) effectinstance.getDuration() + 0.5D);
                if (duration > 0) {
                    focusEntity.addEffect(new MobEffectInstance(effect, duration, effectinstance.getAmplifier(),
                        effectinstance.isAmbient(), effectinstance.isVisible()));
                }
            }
        }
    }

    public void resetAlreadyHits() {
        if (this.alreadyHits != null) {
            alreadyHits.clear();
        }
    }

    public void setHitEntity(Entity hitEntity) {
        if (!hitEntity.equals(this)) {
            this.entityData.set(HIT_ENTITY_ID, hitEntity.getId());

            this.entityData.set(OFFSET_YAW, this.random.nextFloat() * 360);

            this.setDelay(20 * 5);
        }
    }

    @Nullable
    public Entity getHitEntity() {
        if (hitEntity == null) {
            int id = this.entityData.get(HIT_ENTITY_ID);
            if (0 <= id) {
                hitEntity = this.level().getEntity(id);
            }
        }
        return hitEntity;
    }

    public float getOffsetYaw() {
        return this.entityData.get(OFFSET_YAW);
    }

    public float getRoll() {
        return this.entityData.get(ROLL);
    }

    public void setRoll(float value) {
        this.entityData.set(ROLL, value);
    }

    public void setDamage(double damageIn) {
        this.damage = damageIn;
    }

    @Override
    public double getDamage() {
        return this.damage;
    }

    private static final String defaultModelName = "slashblade:model/util/ss";

    public void setModelName(@Nullable String name) {
        this.entityData.set(MODEL, Optional.ofNullable(name).orElse(defaultModelName));
    }

    public String getModelName() {
        String name = this.entityData.get(MODEL);
        if (name.isEmpty()) {
            name = defaultModelName;
        }
        return name;
    }

    public Supplier<ResourceLocation> modelLoc = () -> ResourceLocation.parse(getModelName() + ".obj");
    public Supplier<ResourceLocation> textureLoc = () -> ResourceLocation.parse(getModelName() + ".png");

    public ResourceLocation getModelLoc() {
        return modelLoc.get();
    }

    public ResourceLocation getTextureLoc() {
        return textureLoc.get();
    }

    @Override
    public void push(Entity entityIn) {
        // Suppress velocity change due to collision
        // super.applyEntityCollision(entityIn);
    }

}
