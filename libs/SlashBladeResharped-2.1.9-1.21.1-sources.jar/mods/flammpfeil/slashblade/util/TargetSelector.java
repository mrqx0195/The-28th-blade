package mods.flammpfeil.slashblade.util;

import com.google.common.collect.Lists;
import mods.flammpfeil.slashblade.SlashBladeConfig;
import mods.flammpfeil.slashblade.capability.slashblade.BladeStateAccess;
import mods.flammpfeil.slashblade.data.tag.SlashBladeEntityTypeTagProvider.EntityTypeTags;
import mods.flammpfeil.slashblade.entity.IShootable;
import mods.flammpfeil.slashblade.event.handler.InputCommandEvent;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.entity.PartEntity;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TargetSelector {
    static public final TargetingConditions lockon = new SlashBladeTargetingConditions().range(40.0D)
        .selector(new AttackablePredicate());
    
    static public final TargetingConditions test = new SlashBladeTargetingConditions()
        .selector(new AttackablePredicate());
    
    static final String AttackableTag = "RevengeAttacker";
    
    static boolean isAttackable(@Nullable Entity revengeTarget, @Nullable Entity attacker) {
        return revengeTarget != null && attacker != null
            && (revengeTarget.equals(attacker) || revengeTarget.isAlliedTo(attacker));
    }
    
    static public final TargetingConditions areaAttack = new SlashBladeTargetingConditions().range(12.0D)
        .ignoreInvisibilityTesting().selector(new AttackablePredicate());
    
    static public TargetingConditions getAreaAttackPredicate(double reach) {
        return areaAttack.copy().range(reach);
    }
    
    static public class AttackablePredicate implements Predicate<LivingEntity> {
        
        @Override
        public boolean test(LivingEntity livingentity) {
            
            if (!SlashBladeConfig.PVP_ENABLE.get() && livingentity instanceof Player) {
                return false;
            }
            
            if (livingentity instanceof ArmorStand) {
                return ((ArmorStand) livingentity).isMarker();
            }
            
            if (livingentity.getTags().contains(AttackableTag)) {
                livingentity.removeTag(AttackableTag);
                return true;
            }

            // 防误伤宠物机制
            if (livingentity instanceof OwnableEntity ownable) {
                if (ownable.getOwner() instanceof Player) {
                    return false;
                }
            }

            if (livingentity.getType().is(EntityTypeTags.ATTACKABLE_WHITELIST)) {
                return true;
            }
            
            if (!SlashBladeConfig.FRIENDLY_ENABLE.get() && !(livingentity instanceof Enemy)) {
                return false;
            }
            
            if (livingentity.hasPassenger(entity -> entity instanceof Player)) {
                return false;
            }
            
            if (livingentity.isCurrentlyGlowing()) {
                return true;
            }
            
            if (livingentity.getTeam() != null) {
                return true;
            }
            
            return !livingentity.getType().is(EntityTypeTags.ATTACKABLE_BLACKLIST);
        }
    }
    
    static public List<Entity> getReflectableEntitiesWithinAABB(LivingEntity attacker) {
        double reach = TargetSelector.getResolvedReach(attacker);
        
        AABB aabb = getResolvedAxisAligned(attacker.getBoundingBox(), attacker.getLookAngle(), reach);
        Level world = attacker.level();
        return world.getEntitiesOfClass(Projectile.class, aabb).stream()
            .filter(e -> ((e.getOwner() == null || !e.getOwner().equals(attacker))
                && (!(e instanceof IShootable) || !Objects.equals(((IShootable) e).getShooter(), attacker))))
            .filter(e -> (distanceSqrBetweenEntity(e, attacker) < (reach * reach)))
            .collect(Collectors.toList());
    }
    
    static public List<Entity> getExtinguishableEntitiesWithinAABB(LivingEntity attacker) {
        double reach = TargetSelector.getResolvedReach(attacker);
        
        AABB aabb = getResolvedAxisAligned(attacker.getBoundingBox(), attacker.getLookAngle(), reach);
        Level world = attacker.level();
        return world.getEntitiesOfClass(PrimedTnt.class, aabb).stream()
            .filter(e -> (distanceSqrBetweenEntity(e, attacker) < (reach * reach))).collect(Collectors.toList());
    }
    
    static public List<Entity> getTargettableEntitiesWithinAABB(Level world, LivingEntity attacker) {
        return getTargettableEntitiesWithinAABB(world, attacker,
            getResolvedAxisAligned(attacker.getBoundingBox(), attacker.getLookAngle(), getResolvedReach(attacker)));
    }
    
    static public List<Entity> getTargettableEntitiesWithinAABB(Level world, LivingEntity attacker, AABB aabb) {
        double reach = TargetSelector.getResolvedReach(attacker);
        
        return getTargettableEntitiesWithinAABB(world, attacker, aabb, reach);
    }
    
    public static List<Entity> getTargettableEntitiesWithinAABB(Level world, LivingEntity attacker, AABB aabb,
                                                                double reach) {
        List<Entity> list1 = Lists.newArrayList();
        
        list1.addAll(getReflectableEntitiesWithinAABB(attacker));
        list1.addAll(getExtinguishableEntitiesWithinAABB(attacker));
        
        list1.addAll(world.getEntitiesOfClass(LivingEntity.class, aabb.inflate(5), Entity::isMultipartEntity).stream()
            .flatMap(e -> (e.isMultipartEntity()) ? Stream.of(e.getParts()) : Stream.of(e)).filter(t -> {
                boolean result = false;
                var check = new AttackablePredicate();
                if (t instanceof LivingEntity living) {
                    result = check.test(living) && distanceSqrBetweenEntity(living, attacker) < (reach * reach);
                } else if (t instanceof PartEntity<?> part) {
                    if (part.getParent() instanceof LivingEntity living) {
                        result = check.test(living) && distanceSqrBetweenEntity(part, attacker) < (reach * reach);
                    }
                }
                return result;
            }).toList());
        
        TargetingConditions predicate = getAreaAttackPredicate(reach).range(-1);
        
        list1.addAll(world.getEntitiesOfClass(LivingEntity.class, aabb).stream()
            .flatMap(e -> (e.isMultipartEntity()) ? Stream.of(e.getParts()) : Stream.of(e)).filter(t -> {
                boolean result = false;
                if (t instanceof LivingEntity living) {
                    result = predicate.test(attacker, living) && distanceSqrBetweenEntity(living, attacker) < (reach * reach);
                } else if (t instanceof PartEntity<?> part) {
                    if (part.getParent() instanceof LivingEntity living) {
                        result = predicate.test(attacker, living) && distanceSqrBetweenEntity(part, attacker) < (reach * reach);
                    }
                }
                return result;
            }).toList());
        
        return list1;
    }
    
    static public <E extends Entity & IShootable> List<Entity> getTargettableEntitiesWithinAABB(Level world,
                                                                                                double reach, E owner) {
        AABB aabb = owner.getBoundingBox().inflate(reach);
        
        List<Entity> list1 = Lists.newArrayList();
        
        list1.addAll(world.getEntitiesOfClass(EnderDragon.class, aabb.inflate(5)).stream()
            .flatMap(d -> Arrays.stream(d.getSubEntities())).filter(e -> (distanceSqrBetweenEntity(e, owner) < (reach * reach)))
            .toList());
        
        LivingEntity user;
        if (owner.getShooter() instanceof LivingEntity) {
            user = (LivingEntity) owner.getShooter();
        } else {
            user = null;
        }
        
        list1.addAll(getReflectableEntitiesWithinAABB(world, reach, owner));
        
        TargetingConditions predicate = getAreaAttackPredicate(-1); // reach check has already been completed
        
        list1.addAll(world.getEntitiesOfClass(LivingEntity.class, aabb, (e) -> true).stream()
            .filter(t -> predicate.test(user, t)).toList());
        
        return list1;
    }
    
    static public <E extends Entity & IShootable> List<Entity> getReflectableEntitiesWithinAABB(Level world,
                                                                                                double reach, E owner) {
        AABB aabb = owner.getBoundingBox().inflate(reach);
        
        return world.getEntitiesOfClass(Projectile.class, aabb).stream()
            .filter(e -> (e.getOwner() == null
                || !e.getOwner().equals(owner.getShooter())))
            .filter(e -> (distanceSqrBetweenEntity(e, owner) < (reach * reach)) && !e.equals(owner))
            .collect(Collectors.toList());
    }
    
    static public AABB getResolvedAxisAligned(AABB bb, Vec3 dir, double reach) {
        final double padding = 1.0;
        
        if (dir.equals(Vec3.ZERO)) {
            bb = bb.inflate(reach * 2);
        } else {
            bb = bb.move(dir.scale(reach * 0.5)).inflate(reach);
        }
        
        bb = bb.inflate(padding);
        
        return bb;
    }
    
    static public double getResolvedReach(LivingEntity user) {
        double reach = 4.0D; /* 4 block */
        AttributeInstance attrib = user.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
        if (attrib != null) {
            reach = attrib.getValue() - 1;
        }
        return reach;
    }
    
    public static double distanceBetweenEntity(Entity a, Entity b) {
        return distanceBetweenAABB(a.getBoundingBox(), b.getBoundingBox());
    }
    
    public static double distanceBetweenAABB(AABB a, AABB b) {
        return Math.sqrt(distanceSqrBetweenAABB(a, b));
    }
    
    public static double distanceSqrBetweenEntity(Entity a, Entity b) {
        return distanceSqrBetweenAABB(a.getBoundingBox(), b.getBoundingBox());
    }
    
    public static double distanceSqrBetweenAABB(AABB a, AABB b) {
        double dx = Math.max(0.0, Math.max(a.minX - b.maxX, b.minX - a.maxX));
        double dy = Math.max(0.0, Math.max(a.minY - b.maxY, b.minY - a.maxY));
        double dz = Math.max(0.0, Math.max(a.minZ - b.maxZ, b.minZ - a.maxZ));
        
        return dx * dx + dy * dy + dz * dz;
    }
    
    @SubscribeEvent
    public static void onInputChange(InputCommandEvent event) {
        
        EnumSet<InputCommand> old = event.getOld();
        EnumSet<InputCommand> current = event.getCurrent();
        ServerPlayer sender = event.getEntity();
        
        
        ItemStack stack = sender.getMainHandItem();
        if (stack.isEmpty()) {
            return;
        }
        if (!(stack.getItem() instanceof ItemSlashBlade)) {
            return;
        }
        
        // SneakHold & Middle Click
        if (!(!old.contains(InputCommand.M_DOWN) && current.contains(InputCommand.M_DOWN)
            && current.contains(InputCommand.SNEAK))) {
            return;
        }
        
        BladeStateAccess.of(stack).ifPresent(s -> {
            Entity tmp = s.getTargetEntity(sender.level());
            if (tmp == null) {
                return;
            }
            if (!(tmp instanceof LivingEntity target)) {
                return;
            }
            
            if (Objects.equals(target.getLastHurtByMob(), sender)) {
                return;
            }
            
            target.setLastHurtByMob(sender);
            
            if (target.level() instanceof ServerLevel sw) {
                
                sw.sendParticles(sender, ParticleTypes.ANGRY_VILLAGER, false, target.getX(),
                    target.getY() + target.getEyeHeight(), target.getZ(), 5, target.getBbWidth() * 1.5,
                    target.getBbHeight(), target.getBbWidth() * 1.5, 0.02D);
            }
        });
    }
    
    public static class SlashBladeTargetingConditions extends TargetingConditions {
        
        public SlashBladeTargetingConditions() {
            super(true);
        }
        
        @Override
        public boolean test(@Nullable LivingEntity attacker, LivingEntity target) {
            boolean isAttackable = false;
            
            isAttackable |= isAttackable(target.getLastHurtByMob(), attacker);
            
            if (!isAttackable && target instanceof Mob) {
                isAttackable = isAttackable(((Mob) target).getTarget(), attacker);
            }
            
            if (isAttackable) {
                target.addTag(AttackableTag);
            }
            
            return super.test(attacker, target);
        }
    }
    
}
