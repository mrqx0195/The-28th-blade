package net.mrqx.sbr_core.client.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.client.renderer.CarryTypeRenderAction;
import mods.flammpfeil.slashblade.client.renderer.layers.LayerSlashBlade;
import mods.flammpfeil.slashblade.client.renderer.model.BladeModelManager;
import mods.flammpfeil.slashblade.client.renderer.model.obj.WavefrontObject;
import mods.flammpfeil.slashblade.client.renderer.util.BladeRenderState;
import mods.flammpfeil.slashblade.client.renderer.util.MSAutoCloser;
import mods.flammpfeil.slashblade.init.DefaultResources;
import mods.flammpfeil.slashblade.registry.combo.ComboState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.util.Objects;

/**
 * 原版风格攻击的拔刀剑渲染层。
 */
public class LayerVanillaStyleBlade<T extends LivingEntity, M extends EntityModel<T>> extends LayerSlashBlade<T, M> {
    /**
     * @param renderer 父渲染器
     */
    public LayerVanillaStyleBlade(RenderLayerParent<T, M> renderer) {
        super(renderer);
    }
    
    @Override
    protected void renderMainBlade(PoseStack matrixStack, MultiBufferSource bufferIn, int lightIn,
                                   T entity, float partialTicks, ItemStack stack,
                                   ISlashBladeState state, ComboState combo, double timeMSec) {
        ResourceLocation textureLocation = state.getTexture().orElse(DefaultResources.resourceDefaultTexture);
        WavefrontObject obj = BladeModelManager.getInstance()
            .getModel(state.getModel().orElse(DefaultResources.resourceDefaultModel));
        String part;
        if (state.isBroken()) {
            part = "blade_damaged";
        } else {
            part = "blade";
        }
        
        try (MSAutoCloser ignored = MSAutoCloser.pushMatrix(matrixStack)) {
            try (MSAutoCloser ignored1 = MSAutoCloser.pushMatrix(matrixStack)) {
                matrixStack.translate(0, 1.5, 0);
                
                CarryTypeRenderAction carryTypeRenderAction = CARRY_TYPE_RENDER_ACTION_MAP.getOrDefault(state.getCarryType(), CarryTypeRenderAction.DEFAULT_CARRY_TYPE_RENDER_ACTION);
                carryTypeRenderAction.standbyRenderAction().accept(matrixStack);
                
                double modelScaleBase = 0.0078125F;
                double motionScale = 1.5 / 12.0;
                float modelScale = (float) (modelScaleBase * (1.0f / motionScale));
                matrixStack.scale((float) motionScale, (float) motionScale, (float) motionScale);
                matrixStack.scale(modelScale, modelScale, modelScale);
                
                BladeRenderState.renderOverrided(stack, obj, "sheath", textureLocation, matrixStack, bufferIn,
                    lightIn);
                BladeRenderState.renderOverridedLuminous(stack, obj, SHEATH_LUMINOUS, textureLocation,
                    matrixStack, bufferIn, lightIn);
            }
            
            try (MSAutoCloser ignored1 = MSAutoCloser.pushMatrix(matrixStack)) {
                if (this.translateToMainHand(matrixStack, entity, partialTicks)) {
                    BladeRenderState.renderOverrided(stack, obj, part, textureLocation, matrixStack, bufferIn,
                        lightIn);
                    BladeRenderState.renderOverridedLuminous(stack, obj,
                        state.isBroken() ? BLADE_DAMAGED_LUMINOUS : BLADE_LUMINOUS, textureLocation,
                        matrixStack, bufferIn, lightIn);
                }
            }
        }
    }
    
    public boolean translateToMainHand(PoseStack matrixStack, T entity, float partialTicks) {
        HumanoidArm arm = entity.getMainArm();
        int side = arm == HumanoidArm.RIGHT ? 1 : -1;
        
        if (this.isFirstPerson(entity)) {
            this.applyFirstPersonItemTransform(matrixStack, entity, side, partialTicks);
            
            matrixStack.mulPose(Axis.XP.rotationDegrees(15));
            matrixStack.mulPose(Axis.YP.rotationDegrees(-90));
            matrixStack.mulPose(Axis.ZP.rotationDegrees(90.0F));
        } else {
            EntityModel<T> parentModel = this.getParentModel();
            if (!(parentModel instanceof ArmedModel armedModel)) {
                return false;
            }
            
            if (parentModel.young) {
                matrixStack.translate(0.0F, 0.75F, 0.0F);
                matrixStack.scale(0.5F, 0.5F, 0.5F);
            }
            
            armedModel.translateToHand(arm, matrixStack);
            
            matrixStack.mulPose(Axis.XP.rotationDegrees(-90.0F));
            matrixStack.mulPose(Axis.YP.rotationDegrees(180.0F));
            matrixStack.translate((float) side / 16.0F, 0.125F, -0.625F);
            
            matrixStack.mulPose(Axis.YP.rotationDegrees(90.0F));
            matrixStack.mulPose(Axis.ZP.rotationDegrees(-90.0F));
        }
        
        matrixStack.scale(0.0078125F, 0.0078125F, 0.0078125F);
        
        return true;
    }
    
    public boolean isFirstPerson(T entity) {
        Minecraft minecraft = Minecraft.getInstance();
        return Objects.equals(minecraft.player, entity) && minecraft.options.getCameraType().isFirstPerson();
    }
    
    public void applyFirstPersonItemTransform(PoseStack matrixStack, T entity, int side, float partialTicks) {
        float swing = entity.swingingArm == InteractionHand.MAIN_HAND ? entity.getAttackAnim(partialTicks) : 0.0F;
        
        float swingX = -0.4F * Mth.sin(Mth.sqrt(swing) * (float) Math.PI);
        float swingY = 0.2F * Mth.sin(Mth.sqrt(swing) * (float) (Math.PI * 2.0));
        float swingZ = -0.2F * Mth.sin(swing * (float) Math.PI);
        matrixStack.translate(-(float) side * swingX, -swingY, swingZ);
        
        matrixStack.translate(-(float) side * 0.56F, 0.52F, -0.07F);
        
        // 攻击挥舞：原版 applyItemArmAttackTransform 的四段旋转（Y: 45→25、Z: -20·sin、X: -80·sin、Y: -45）
        float attack = Mth.sin(swing * swing * (float) Math.PI);
        float attackSqrt = Mth.sin(Mth.sqrt(swing) * (float) Math.PI);
        matrixStack.mulPose(Axis.YP.rotationDegrees(-(float) side * (45.0F + attack * -20.0F)));
        matrixStack.mulPose(Axis.ZP.rotationDegrees((float) side * attackSqrt * -20.0F));
        matrixStack.mulPose(Axis.XP.rotationDegrees(attackSqrt * 80.0F));
        matrixStack.mulPose(Axis.YP.rotationDegrees((float) side * 45.0F));
    }
    
    @Override
    protected double getMaxSeconds(ComboState comboState) {
        return 0;
    }
}
