package mods.flammpfeil.slashblade.entity;

import mods.flammpfeil.slashblade.ability.StunManager;
import mods.flammpfeil.slashblade.capability.concentrationrank.CapabilityConcentrationRank;
import mods.flammpfeil.slashblade.capability.concentrationrank.IConcentrationRank;
import mods.flammpfeil.slashblade.capability.slashblade.BladeStateAccess;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.util.AttackManager;
import mods.flammpfeil.slashblade.util.EnumSetConverter;
import mods.flammpfeil.slashblade.util.KnockBacks;
import mods.flammpfeil.slashblade.util.NBTHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.entity.PartEntity;

import javax.annotation.Nullable;

import static mods.flammpfeil.slashblade.SlashBladeConfig.REFINE_DAMAGE_MULTIPLIER;
import static mods.flammpfeil.slashblade.SlashBladeConfig.SLASHBLADE_DAMAGE_MULTIPLIER;

public class EntityDrive extends EntityAbstractSummonedSword {
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(EntityDrive.class,
        EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> FLAGS = SynchedEntityData.defineId(EntityDrive.class,
        EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> RANK = SynchedEntityData.defineId(EntityDrive.class,
        EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROTATION_OFFSET = SynchedEntityData
        .defineId(EntityDrive.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROTATION_ROLL = SynchedEntityData.defineId(EntityDrive.class,
        EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> BASESIZE = SynchedEntityData.defineId(EntityDrive.class,
        EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> SPEED = SynchedEntityData.defineId(EntityDrive.class,
        EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> LIFETIME = SynchedEntityData.defineId(EntityDrive.class, EntityDataSerializers.FLOAT);
    
    private KnockBacks action = KnockBacks.cancel;
    
    private double damage = 7.0D;
    
    public KnockBacks getKnockBack() {
        return action;
    }
    
    public void setKnockBack(KnockBacks action) {
        this.action = action;
    }
    
    public void setKnockBackOrdinal(int ordinal) {
        if (0 <= ordinal && ordinal < KnockBacks.values().length) {
            this.action = KnockBacks.values()[ordinal];
        } else {
            this.action = KnockBacks.cancel;
        }
    }
    
    public EntityDrive(EntityType<? extends Projectile> entityTypeIn, Level worldIn) {
        super(entityTypeIn, worldIn);
        this.setNoGravity(true);
        // this.setGlowing(true);
    }
    
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(COLOR, 0x3333FF);
        builder.define(FLAGS, 0);
        builder.define(RANK, 0.0f);
        builder.define(LIFETIME, 10.0f);
        
        builder.define(ROTATION_OFFSET, 0.0f);
        builder.define(ROTATION_ROLL, 0.0f);
        builder.define(BASESIZE, 1.0f);
        builder.define(SPEED, 0.5f);
    }
    
    @Override
    public void addAdditionalSaveData(CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        
        NBTHelper.getNBTCoupler(compound).put("RotationOffset", this.getRotationOffset())
            .put("RotationRoll", this.getRotationRoll()).put("BaseSize", this.getBaseSize())
            .put("Speed", this.getSpeed()).put("Color", this.getColor()).put("Rank", this.getRank())
            .put("damage", this.damage).put("crit", this.getIsCritical()).put("clip", this.isNoClip())
            .put("Lifetime", this.getLifetime()).put("Knockback", this.getKnockBack().ordinal());
    }
    
    @Override
    public void readAdditionalSaveData(CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        
        NBTHelper.getNBTCoupler(compound).get("RotationOffset", this::setRotationOffset)
            .get("RotationRoll", this::setRotationRoll).get("BaseSize", this::setBaseSize)
            .get("Speed", this::setSpeed).get("Color", this::setColor).get("Rank", this::setRank)
            .get("damage", ((Double v) -> this.damage = v), this.damage).get("crit", this::setIsCritical)
            .get("clip", this::setNoClip).get("Lifetime", this::setLifetime)
            .get("Knockback", this::setKnockBackOrdinal);
    }
    
    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket(ServerEntity entity) {
        return super.getAddEntityPacket(entity);
    }
    
    @Override
    @OnlyIn(Dist.CLIENT)
    public boolean shouldRenderAtSqrDistance(double distance) {
        double d0 = this.getBoundingBox().getSize() * 10.0D;
        if (Double.isNaN(d0)) {
            d0 = 1.0D;
        }
        
        d0 = d0 * 64.0D * getViewScale();
        return distance < d0 * d0;
    }
    
    @Override
    protected void removeFlags(FlagsState value) {
        this.flags.remove(value);
        refreshFlags();
    }
    
    private void refreshFlags() {
        if (this.level().isClientSide()) {
            int newValue = this.entityData.get(FLAGS);
            if (intFlags != newValue) {
                intFlags = newValue;
                flags = EnumSetConverter.convertToEnumSet(FlagsState.class, intFlags);
            }
        } else {
            int newValue = EnumSetConverter.convertToInt(this.flags);
            if (this.intFlags != newValue) {
                this.entityData.set(FLAGS, newValue);
                this.intFlags = newValue;
            }
        }
    }
    
    @Override
    public void tick() {
        super.tick();
        tryDespawn();
    }
    
    @Override
    protected void tryDespawn() {
        if (!this.level().isClientSide()) {
            if (getLifetime() < this.tickCount) {
                this.remove(RemovalReason.DISCARDED);
            }
        }
    }
    
    @Override
    public int getColor() {
        return this.getEntityData().get(COLOR);
    }
    
    @Override
    public void setColor(int value) {
        this.getEntityData().set(COLOR, value);
    }
    
    public float getRank() {
        return this.getEntityData().get(RANK);
    }
    
    public void setRank(float value) {
        this.getEntityData().set(RANK, value);
    }
    
    @Nullable
    public IConcentrationRank.ConcentrationRanks getRankCode() {
        return IConcentrationRank.ConcentrationRanks.getRankFromLevel(getRank());
    }
    
    public float getRotationOffset() {
        return this.getEntityData().get(ROTATION_OFFSET);
    }
    
    public void setRotationOffset(float value) {
        this.getEntityData().set(ROTATION_OFFSET, value);
    }
    
    public float getRotationRoll() {
        return this.getEntityData().get(ROTATION_ROLL);
    }
    
    public void setRotationRoll(float value) {
        this.getEntityData().set(ROTATION_ROLL, value);
    }
    
    public float getBaseSize() {
        return this.getEntityData().get(BASESIZE);
    }
    
    public void setBaseSize(float value) {
        this.getEntityData().set(BASESIZE, value);
    }
    
    public float getSpeed() {
        return this.getEntityData().get(SPEED);
    }
    
    public void setSpeed(float value) {
        this.getEntityData().set(SPEED, value);
    }
    
    public float getLifetime() {
        return this.getEntityData().get(LIFETIME);
    }
    
    public void setLifetime(float value) {
        this.getEntityData().set(LIFETIME, value);
    }
    
    @Override
    public void setShooter(Entity shooter) {
        super.setShooter(shooter);
    }
    
    @Override
    public void setDamage(double damageIn) {
        this.damage = damageIn;
    }
    
    @Override
    public double getDamage() {
        return this.damage;
    }
    
    @Override
    protected void onHitEntity(EntityHitResult entityHitResult) {
        Entity targetEntity = entityHitResult.getEntity();
        float damageValue = (float) this.getDamage();
        
        Entity shooter = this.getShooter();
        DamageSource damagesource;
        if (shooter == null) {
            damagesource = this.damageSources().indirectMagic(this, this);
        } else {
            damagesource = this.damageSources().indirectMagic(this, shooter);
            if (shooter instanceof LivingEntity) {
                Entity hits = targetEntity;
                if (targetEntity instanceof PartEntity) {
                    hits = ((PartEntity<?>) targetEntity).getParent();
                }
                ((LivingEntity) shooter).setLastHurtMob(hits);
            }
        }
        
        int fireTime = targetEntity.getRemainingFireTicks();
        if (this.isOnFire() && !(targetEntity instanceof EnderMan)) {
            targetEntity.setRemainingFireTicks(5 * 20);
        }
        
        // todo: attack manager
        targetEntity.invulnerableTime = 0;
        if (this.getOwner() instanceof LivingEntity living) {
            damageValue *= (float) living.getAttributeValue(Attributes.ATTACK_DAMAGE);
            //评分等级加成
            if (living instanceof Player player) {
                IConcentrationRank.ConcentrationRanks rankBonus = player.hasData(CapabilityConcentrationRank.RANK_POINT.get())
                    ? player.getData(CapabilityConcentrationRank.RANK_POINT.get()).getRank(player.level().getGameTime())
                    : IConcentrationRank.ConcentrationRanks.NONE;
                if (rankBonus != null) {
                    float rankDamageBonus = rankBonus.level / 2.0f;
                    if (IConcentrationRank.ConcentrationRanks.S.level <= rankBonus.level) {
                        int refine = BladeStateAccess.of(player.getMainHandItem()).map(ISlashBladeState::getRefine).orElse(0);
                        int level = player.experienceLevel;
                        rankDamageBonus = (float) Math.max(rankDamageBonus, Math.min(level, refine) * REFINE_DAMAGE_MULTIPLIER.get());
                    }
                    damageValue += rankDamageBonus;
                }
            }
            damageValue *= (float) (AttackManager.getSlashBladeDamageScale(living) * SLASHBLADE_DAMAGE_MULTIPLIER.get());
            if (this.getIsCritical()) {
                damageValue += this.random.nextInt((Mth.ceil(damageValue) / 2 + 2));
            }
        }
        
        if (targetEntity.hurt(damagesource, damageValue)) {
            Entity hits = targetEntity;
            if (targetEntity instanceof PartEntity) {
                hits = ((PartEntity<?>) targetEntity).getParent();
            }
            
            if (hits instanceof LivingEntity targetLivingEntity) {
                
                StunManager.setStun(targetLivingEntity);
                if (!this.level().isClientSide() && shooter instanceof LivingEntity) {
                    EnchantmentHelper.doPostAttackEffects((ServerLevel) this.level(), targetLivingEntity, damagesource);
                }
                
                affectEntity(targetLivingEntity, getPotionEffects(), 1.0f);
                
                if (!targetLivingEntity.equals(shooter) && targetLivingEntity instanceof Player
                    && shooter instanceof ServerPlayer) {
                    ((ServerPlayer) shooter).playNotifySound(this.getHitEntityPlayerSound(), SoundSource.PLAYERS, 0.18F,
                        0.45F);
                }
            }
            
            this.playSound(this.getHitEntitySound(), 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
        } else {
            targetEntity.setRemainingFireTicks(fireTime);
        }
    }
    
    @Override
    protected void onHitBlock(BlockHitResult blockraytraceresult) {
        this.setRemoved(RemovalReason.DISCARDED);
    }
    
    @Override
    @Nullable
    public EntityHitResult getRayTrace(Vec3 p_213866_1_, Vec3 p_213866_2_) {
        return ProjectileUtil.getEntityHitResult(this.level(), this, p_213866_1_, p_213866_2_,
            this.getBoundingBox().expandTowards(this.getDeltaMovement()).inflate(1.0D), (entity) -> !entity.isSpectator() && entity.isAlive() && entity.isPickable()
                && (!entity.equals(this.getShooter())));
    }
}
