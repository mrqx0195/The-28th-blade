package net.mrqx.sbr_core;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.config.MrqxSlashBladeClientConfig;
import net.mrqx.sbr_core.config.MrqxSlashBladeCoreConfig;
import net.mrqx.sbr_core.registry.MrqxComboStateRegistry;
import net.mrqx.sbr_core.registry.MrqxEntityTypesRegistry;
import net.mrqx.sbr_core.registry.MrqxParticleTypesRegistry;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import org.slf4j.Logger;

import javax.annotation.Nullable;

/**
 * MrqxSlashBladeCore 模组主类。
 */
@Mod(MrqxSlashBladeCore.MODID)
public class MrqxSlashBladeCore {
    public static final String MODID = "sbr_core";
    public static final Logger LOGGER = LogUtils.getLogger();
    @Nullable
    private static IEventBus modEventBus;
    
    /**
     * 将给定的字符串路径前缀化为此模组的命名空间路径。
     */
    public static ResourceLocation prefix(String s) {
        return ResourceLocation.fromNamespaceAndPath(MODID, s);
    }
    
    public static ResourceLocation vmdLocBlade(String path) {
        return MrqxSlashBladeCore.prefix("vmd/" + path + ".blade.vmd");
    }
    
    public static ResourceLocation vmdLocPlayer(String path) {
        return MrqxSlashBladeCore.prefix("vmd/" + path + ".player.vmd");
    }
    
    public MrqxSlashBladeCore(IEventBus modEventBus, ModContainer container) {
        MrqxSlashBladeCore.modEventBus = modEventBus;
        MrqxEntityTypesRegistry.ENTITY_TYPES.register(modEventBus);
        MrqxParticleTypesRegistry.PARTICLE_TYPES.register(modEventBus);
        MrqxComboStateRegistry.COMBO_STATES.register(modEventBus);
        container.registerConfig(ModConfig.Type.COMMON, MrqxSlashBladeCoreConfig.COMMON_CONFIG);
        container.registerConfig(ModConfig.Type.CLIENT, MrqxSlashBladeClientConfig.CLIENT_CONFIG);
        
    }
    
    @Nullable
    public static <T extends Event> T postModBusEvent(T event) {
        if (modEventBus == null) {
            return null;
        }
        return modEventBus.post(event);
    }
    
    @Nullable
    public static IEventBus getModEventBus() {
        return modEventBus;
    }
}
