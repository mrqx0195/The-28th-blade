package net.mrqx.sbr_core.client;

import com.google.common.collect.Maps;
import mods.flammpfeil.slashblade.compat.playerAnim.PlayerAnimationOverrider;
import mods.flammpfeil.slashblade.compat.playerAnim.VmdAnimation;
import net.minecraft.resources.ResourceLocation;
import net.mrqx.sbr_core.animation.VanillaConvertedVmdAnimation;

import java.util.Map;

/**
 * 客户端动画存储。
 * <p>
 * 在初始化时从 {@link PlayerAnimationOverrider} 中读取所有 VMD 动画，
 * 转换为 {@link VanillaConvertedVmdAnimation} 存储以供查询。
 */
public class ClientAnimations {
    public static final Map<ResourceLocation, VanillaConvertedVmdAnimation> ANIMATION = initAnimations();
    
    /**
     * 初始化动画映射表：遍历已注册的动画并转换为 VanillaConvertedVmdAnimation。
     */
    private static Map<ResourceLocation, VanillaConvertedVmdAnimation> initAnimations() {
        Map<ResourceLocation, VanillaConvertedVmdAnimation> map = Maps.newHashMap();
        PlayerAnimationOverrider.getInstance().getAnimation().forEach((resourceLocation, animation) -> {
            if (animation.get() instanceof VmdAnimation vmdAnimation) {
                map.put(resourceLocation, VanillaConvertedVmdAnimation.of(vmdAnimation));
            }
        });
        return map;
    }
}
