package net.mrqx.sbr_core.client;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.client.renderer.entity.SummonedSwordRenderer;
import mods.flammpfeil.slashblade.event.client.LayerSlashBladeInitEvent;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.mrqx.sbr_core.client.effect.debris.DebrisMesh;
import net.mrqx.sbr_core.client.effect.mesh.MeshShard;
import net.mrqx.sbr_core.client.effect.mesh.SceneDepthCopy;
import net.mrqx.sbr_core.client.effect.post.PostEffectRegistry;
import net.mrqx.sbr_core.client.layer.LayerVanillaStyleBlade;
import net.mrqx.sbr_core.client.renderer.RendererSlashString;
import net.mrqx.sbr_core.client.renderer.entity.RendererAdvanceSlashEffect;
import net.mrqx.sbr_core.registry.MrqxComboStateRegistry;
import net.mrqx.sbr_core.registry.MrqxEntityTypesRegistry;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;

/**
 * 本 Mod 客户端侧 MOD 总线事件订阅者。
 */
@EventBusSubscriber(value = Dist.CLIENT)
public final class ClientHandler {
    /**
     * 注册客户端资源重载监听器，资源重载完成后重建畸变 PostChain 与网格缓存，并释放场景深度副本。
     */
    @SubscribeEvent
    public static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener(new SimplePreparableReloadListener<ResourceManager>() {
            @Override
            protected ResourceManager prepare(ResourceManager resourceManager, ProfilerFiller profiler) {
                return resourceManager;
            }
            
            @Override
            protected void apply(ResourceManager object, ResourceManager resourceManager, ProfilerFiller profiler) {
                PostEffectRegistry.reload(resourceManager);
                MeshShard.reload();
                DebrisMesh.reload();
                // 深度副本是纯粹的 GL 资源、不依赖资源包内容，但重载是一次"该收拾的都收拾"的时机；
                // 尺寸变化时的重建在 SceneDepthCopy 内部另有处理，这里只补上"重载时释放"这一半。
                SceneDepthCopy.release();
            }
        });
    }
    
    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(MrqxEntityTypesRegistry.ADVANCE_SLASH_EFFECT.get(), RendererAdvanceSlashEffect::new);
        event.registerEntityRenderer(MrqxEntityTypesRegistry.AIR_TRICK_SUMMONED_SWORD.get(), SummonedSwordRenderer::new);
        event.registerEntityRenderer(MrqxEntityTypesRegistry.SLASH_STRING.get(), RendererSlashString::new);
    }
    
    @SubscribeEvent
    public static void onFMLCommonSetupEvent(FMLCommonSetupEvent event) {
        SlashBlade.MOD_EVENT_BUS.addListener(ClientHandler::onLayerSlashBladeInitEvent);
    }
    
    public static void onLayerSlashBladeInitEvent(LayerSlashBladeInitEvent event) {
        event.register(MrqxComboStateRegistry.VANILLA_STYLE_STANDBY.getId(), LayerVanillaStyleBlade::new);
    }
}
