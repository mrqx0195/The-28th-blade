package net.mrqx.sbr_core.registry;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.registry.combo.ComboState;
import mods.flammpfeil.slashblade.util.AttackManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.mrqx.sbr_core.MrqxSlashBladeCore;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Function;

public final class MrqxComboStateRegistry {
    public static final DeferredRegister<ComboState> COMBO_STATES = DeferredRegister.create(ComboState.REGISTRY_KEY, MrqxSlashBladeCore.MODID);
    
    public static final net.minecraft.resources.ResourceLocation EMPTY_VMD_BLADE_ANIMATION = MrqxSlashBladeCore.vmdLocBlade("empty_animation");
    
    public static final ResourceLocation NONE_COMBO = SlashBlade.prefix("none");
    public static final Function<LivingEntity, ResourceLocation> NONE_COMBO_FUNCTION = __ -> NONE_COMBO;
    public static final ComboState.TimeLineTickAction SHEATH_SOUND_ACTION = ComboState.TimeLineTickAction.getBuilder().put(0, AttackManager::playQuickSheathSoundAction).build();
    
    public static final DeferredHolder<ComboState, ComboState> VANILLA_STYLE_STANDBY = COMBO_STATES.register("vanilla_style_standby",
        ComboState.Builder.newInstance().startAndEnd(0, 1).priority(1000).loop().timeout(1000).motionLoc(EMPTY_VMD_BLADE_ANIMATION)
            .next(entity -> entity.level().isClientSide() ? MrqxSlashBladeCore.prefix("vanilla_style_standby") : MrqxSlashBladeCore.prefix("vanilla_style_attack"))
            .nextOfTimeout(NONE_COMBO_FUNCTION)
            ::build);
    
    public static final DeferredHolder<ComboState, ComboState> VANILLA_STYLE_ATTACK = COMBO_STATES.register("vanilla_style_attack",
        ComboState.Builder.newInstance().startAndEnd(0, 1).priority(100).motionLoc(EMPTY_VMD_BLADE_ANIMATION)
            .next(NONE_COMBO_FUNCTION)
            .nextOfTimeout(NONE_COMBO_FUNCTION)
            .clickAction(entity -> {
                if (entity instanceof Player player) {
                    float attackStrengthScale = player.getAttackStrengthScale(0.5f);
                    AttackManager.doSlash(entity, 120, false, false, 0.2F + attackStrengthScale * attackStrengthScale * 0.8F);
                    player.resetAttackStrengthTicker();
                } else {
                    AttackManager.doSlash(entity, 120, false, false, 1);
                }
                entity.swing(InteractionHand.MAIN_HAND);
            })
            ::build);
}
